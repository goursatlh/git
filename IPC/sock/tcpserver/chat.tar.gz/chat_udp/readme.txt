requires:
	1, sev and cli can send datas to peer;
	2, sev and cli can recv datas from peer;
	3, sev and cli cant recv and send datas in the same time;
	4, sev can accept more than one clients in the same time.
	5, users can chat with eath other by the keyboard.
